package com.cg.crs.exception;

@SuppressWarnings("serial")
public class CRSException extends Exception {
public CRSException(String message)
{
	super (message);
}
}
