package com.cg.crs.model;

public class Report {
private  Long claimNumber;
private  String claimReason;
private String accidentStreet;
private String accidentCity;
private String accidentState;
private Integer accidentZip;
private String claimType;
private Long policyNumber;
private String claimQuestion;
private Long claimQuesSeq;
private String busSegId;
private String claimQuesDesc1; 
private String claimQuesAns1;                
private Integer claimQuesDesc2; 
private String claimQuesAns2;              
private Integer claimQuesDesc3;
private String claimQuesAns3;                
private Integer claimQuesDesc4; 
private String claimQuesAns4;                
public Report() {
	// TODO Auto-generated constructor stub
}
public Long getClaimNumber() {
	return claimNumber;
}
public void setClaimNumber(Long claimNumber) {
	this.claimNumber = claimNumber;
}
public String getClaimReason() {
	return claimReason;
}
public void setClaimReason(String claimReason) {
	this.claimReason = claimReason;
}
public String getAccidentStreet() {
	return accidentStreet;
}
public void setAccidentStreet(String accidentStreet) {
	this.accidentStreet = accidentStreet;
}
public String getAccidentCity() {
	return accidentCity;
}
public void setAccidentCity(String accidentCity) {
	this.accidentCity = accidentCity;
}
public String getAccidentState() {
	return accidentState;
}
public void setAccidentState(String accidentState) {
	this.accidentState = accidentState;
}
public Integer getAccidentZip() {
	return accidentZip;
}
public void setAccidentZip(Integer accidentZip) {
	this.accidentZip = accidentZip;
}
public String getClaimType() {
	return claimType;
}
public void setClaimType(String claimType) {
	this.claimType = claimType;
}
public Long getPolicyNumber() {
	return policyNumber;
}
public void setPolicyNumber(Long policyNumber) {
	this.policyNumber = policyNumber;
}
public String getClaimQuestion() {
	return claimQuestion;
}
public void setClaimQuestion(String claimQuestion) {
	this.claimQuestion = claimQuestion;
}
public Long getClaimQuesSeq() {
	return claimQuesSeq;
}
public void setClaimQuesSeq(Long claimQuesSeq) {
	this.claimQuesSeq = claimQuesSeq;
}
public String getBusSegId() {
	return busSegId;
}
public void setBusSegId(String busSegId) {
	this.busSegId = busSegId;
}
public String getClaimQuesDesc1() {
	return claimQuesDesc1;
}
public void setClaimQuesDesc1(String claimQuesDesc1) {
	this.claimQuesDesc1 = claimQuesDesc1;
}
public String getClaimQuesAns1() {
	return claimQuesAns1;
}
public void setClaimQuesAns1(String claimQuesAns1) {
	this.claimQuesAns1 = claimQuesAns1;
}
public Integer getClaimQuesDesc2() {
	return claimQuesDesc2;
}
public void setClaimQuesDesc2(Integer claimQuesDesc2) {
	this.claimQuesDesc2 = claimQuesDesc2;
}
public String getClaimQuesAns2() {
	return claimQuesAns2;
}
public void setClaimQuesAns2(String claimQuesAns2) {
	this.claimQuesAns2 = claimQuesAns2;
}
public Integer getClaimQuesDesc3() {
	return claimQuesDesc3;
}
public void setClaimQuesDesc3(Integer claimQuesDesc3) {
	this.claimQuesDesc3 = claimQuesDesc3;
}
public String getClaimQuesAns3() {
	return claimQuesAns3;
}
public void setClaimQuesAns3(String claimQuesAns3) {
	this.claimQuesAns3 = claimQuesAns3;
}
public Integer getClaimQuesDesc4() {
	return claimQuesDesc4;
}
public void setClaimQuesDesc4(Integer claimQuesDesc4) {
	this.claimQuesDesc4 = claimQuesDesc4;
}
public String getClaimQuesAns4() {
	return claimQuesAns4;
}
public void setClaimQuesAns4(String claimQuesAns4) {
	this.claimQuesAns4 = claimQuesAns4;
}

}
